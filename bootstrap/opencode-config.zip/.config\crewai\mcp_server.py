import sys, os, json, subprocess, gc

sys.path.insert(0, r"C:\xampp\htdocs\liteFramework")
from servidor.crewai.pixelamp_bridge import pixelamp
from crewai.events.event_bus import crewai_event_bus
os.environ["PYTHONIOENCODING"] = "utf-8"
os.environ["PYTHONUTF8"] = "1"
os.environ["CREWAI_LOG_FILE"] = os.path.expanduser("~/.crewai/flow.log")

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", line_buffering=True)
if hasattr(sys.stdin, "reconfigure"):
    sys.stdin.reconfigure(encoding="utf-8", line_buffering=True)

os.makedirs(os.path.expanduser("~/.crewai"), exist_ok=True)

# â”€â”€â”€ Orphan cleanup: PID file (solo mata otro mcp_server.py, NO lite_mcp.py) â”€â”€â”€
import subprocess as _proc
_PID_FILE = os.path.expanduser("~/.crewai/mcp_server.pid")
try:
    if os.path.exists(_PID_FILE):
        with open(_PID_FILE) as _f:
            _old_pid = int(_f.read().strip())
        if _old_pid != os.getpid():
            _proc.run(['taskkill', '/F', '/PID', str(_old_pid)], capture_output=True, timeout=3)
except Exception:
    pass
with open(_PID_FILE, 'w') as _f:
    _f.write(str(os.getpid()))
del _proc, _PID_FILE

_HTTP_FAILED = False

# â”€â”€â”€ Health check helpers â”€â”€â”€
import socket as _socket, time as _time

def _port_5003_pid():
    """Find the PID of the process listening on port 5003, or None."""
    try:
        r = subprocess.run(
            ["netstat", "-ano"], capture_output=True, text=True, timeout=5, encoding="utf-8"
        )
        for line in r.stdout.splitlines():
            if "127.0.0.1:5003" in line and "LISTENING" in line:
                parts = line.strip().split()
                return int(parts[-1])
    except Exception:
        pass
    return None

def _kill_port_5003():
    pid = _port_5003_pid()
    if pid and pid != os.getpid():
        try:
            subprocess.run(["taskkill", "/F", "/PID", str(pid)], capture_output=True, timeout=3)
            _time.sleep(1)
        except Exception:
            pass

def _http_health_ok():
    """Verifica si el puerto 5003 esta escuchando (socket connect).
    NOTA: No usamos POST al endpoint MCP porque lite_mcp_http.py usa
    StreamableHTTP de FastMCP que requiere negociacion de sesion.
    lite_call en los agents funciona por import directo de lite_mcp.py
    (no necesita HTTP), asi que solo verificamos que el proceso exista."""
    try:
        s = _socket.socket(_socket.AF_INET, _socket.SOCK_STREAM)
        s.settimeout(2)
        r = s.connect_ex(("127.0.0.1", 5003))
        s.close()
        return r == 0
    except Exception:
        return False

# â”€â”€â”€ Iniciar lite_mcp HTTP server para CrewAI â”€â”€â”€
_kill_port_5003()
_LITE_MCP_HTTP = None
for _attempt in range(10):
    if _http_health_ok():
        break
    if _LITE_MCP_HTTP is None or _LITE_MCP_HTTP.poll() is not None:
        _LITE_MCP_HTTP = subprocess.Popen(
            [sys.executable, "-u", os.path.join(os.path.dirname(__file__), "lite_mcp_http.py")],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        )
    _time.sleep(1)
else:
    _LITE_MCP_HTTP = None
    # No se pudo iniciar el HTTP server - se reportara en cada kickoff
    _HTTP_FAILED = True

import atexit as _atexit

@_atexit.register
def _cleanup():
    global _LITE_MCP_HTTP
    if _LITE_MCP_HTTP:
        _LITE_MCP_HTTP.terminate()
        try:
            _LITE_MCP_HTTP.wait(timeout=5)
        except Exception:
            pass

del _atexit, _socket, _time

# â”€â”€â”€ MCP handler â”€â”€â”€
_TOOLS = None

def _get_tools():
    global _TOOLS
    if _TOOLS is None:
        _TOOLS = [{
            "name": "kickoff",
            "description": "Ejecuta el flujo completo. El orquestador decide que fases correr.",
            "inputSchema": {
                "type": "object",
                "properties": {"prompt": {"type": "string"}},
                "required": ["prompt"],
            },
        }]
    return _TOOLS


def handle(req):
    method = req.get("method", "")
    _id = req.get("id")
    if method == "initialize":
        return send({
            "jsonrpc": "2.0", "id": _id,
            "result": {
                "protocolVersion": "2024-11-05",
                "capabilities": {"tools": {}},
                "serverInfo": {"name": "crewai_mcp", "version": "2.0.0"},
            },
        })
    if method == "notifications/initialized":
        return
    if method == "tools/list":
        return send({"jsonrpc": "2.0", "id": _id, "result": {"tools": _get_tools()}})
    if method == "tools/call":
        if req["params"]["name"] == "kickoff":
            try:
                warning = ""
                if _HTTP_FAILED:
                    warning = "[INFO] lite_mcp_http (puerto 5003) no responde al health check de socket. lite_call funciona por import directo de lite_mcp.py (no necesita HTTP), los agents operan normalmente.\n\n"
                from crewai import Crew, Task, Agent
                from agents_config import orquestador, pm, data_analyst, opencode_bridge
                prompt = req["params"]["arguments"]["prompt"]
                _manager = Agent(
                    role=orquestador.role,
                    goal=orquestador.goal,
                    backstory=orquestador.backstory,
                    allow_delegation=True,
                    llm=orquestador.llm,
                    max_iter=orquestador.max_iter,
                    cache=orquestador.cache,
                    step_callback=orquestador.step_callback,
                )
                _orq_crew = Crew(
                    agents=[pm, data_analyst, opencode_bridge],
                    tasks=[Task(
                        description=(
                            f"Prompt del usuario: {prompt}\n\n"
                            "Eres el Orquestador (manager del equipo). Tu trabajo:\n"
                            "1. Analiza el prompt y divide el trabajo entre tus agentes:\n"
                            "   - Project Manager (pm): coordina, asigna tareas, da seguimiento\n"
                            "   - Data Analyst (data_analyst): analiza datos, investiga, genera metricas\n"
                            "   - OpenCode Bridge (opencode_bridge): lee/escribe archivos, ejecuta comandos\n"
                            "2. Asigna subtareas a cada agente segun su especialidad.\n"
                            "3. Antes de leer archivos, instruye a los agentes a usar lite_filtrar.\n"
                            "4. Revisa los resultados de cada uno y consolida.\n\n"
                            "RESULTADO: Reporte completo del trabajo del equipo."
                        ),
                        expected_output="Reporte completo del flujo ejecutado",
                        agent=orquestador,
                    )],
                    process="hierarchical",
                    manager_agent=_manager,
                    planning=False,
                    memory=False,
                    function_calling_llm="deepseek-v4-flash",
                    chat_llm="deepseek-v4-flash",
                    max_rpm=15,
                    cache=True,
                )
                pixelamp.setup_listeners(crewai_event_bus)
                result = warning + str(_orq_crew.kickoff())
                send({
                    "jsonrpc": "2.0", "id": _id,
                    "result": {"content": [{"type": "text", "text": result}]},
                })
                gc.collect()
            except Exception as e:
                return send({
                    "jsonrpc": "2.0", "id": _id,
                    "error": {"code": -32603, "message": str(e)},
                })
        return send({
            "jsonrpc": "2.0", "id": _id,
            "error": {"code": -32601, "message": f"Unknown tool: {req['params']['name']}"},
        })
    return send({
        "jsonrpc": "2.0", "id": _id,
        "error": {"code": -32601, "message": f"Unknown method: {method}"},
    })


def send(msg):
    sys.stdout.write(json.dumps(msg, ensure_ascii=False) + "\n")
    sys.stdout.flush()


if __name__ == "__main__":
    while True:
        line = sys.stdin.readline()
        if not line:
            break
        try:
            req = json.loads(line)
            handle(req)
        except json.JSONDecodeError as e:
            send({"jsonrpc": "2.0", "error": {"code": -32700, "message": str(e)}})



