﻿const LAYER_SIZE = 200_000
const MAX_LAYER = 4

const sessions = {}

function getSession(id) {
  if (!sessions[id]) {
    sessions[id] = { layer: 0, lastTokens: 0, providerID: null, modelID: null }
  }
  return sessions[id]
}

export const CompactSignalPlugin = async ({ client }) => {
  let tool
  try {
    tool = (await import("@opencode-ai/plugin")).tool
  } catch {
    tool = (def) => def
  }

  return {
    tool: {
      suggest_compact: tool({
        description: "Compacta el contexto de la sesion cuando detectes que segmentos anteriores ya no son relevantes. Indicadores: tarea completada, tema cambiado, exploracion descartada, debugging que ya no aplica.",
        args: {
          reason: tool.schema ? tool.schema.string({ description: "Explica por que el contexto ya no es relevante" }) : { type: "string" }
        },
        async execute(args, context) {
          const s = getSession(context.sessionID)
          try {
            await client.session.summarize({
              path: { id: context.sessionID },
              body: { providerID: s.providerID, modelID: s.modelID }
            })
            s.layer = 0
            return "Compactado: " + args.reason
          } catch (e) {
            return "Error: " + e.message
          }
        }
      })
    },

    event: async ({ event }) => {
      if (event.type === "message.updated" && event.properties.info.role === "assistant") {
        const info = event.properties.info
        const s = getSession(info.sessionID)
        s.lastTokens = info.tokens.input
        s.providerID = info.providerID
        s.modelID = info.modelID
        return
      }

      if (event.type === "session.idle") {
        const s = getSession(event.properties.sessionID)
        const threshold = (s.layer + 1) * LAYER_SIZE
        if (s.lastTokens < threshold) return

        const msgs = await client.session.messages({ path: { id: event.properties.sessionID } })
        const signals = countSignals(msgs)

        if (signals >= 2) {
          try {
            await client.session.summarize({
              path: { id: event.properties.sessionID },
              body: { providerID: s.providerID, modelID: s.modelID }
            })
            s.layer = 0
          } catch (e) {
            await client.app.log({ body: { service: "compact-signal", level: "error", message: e.message } })
          }
        } else {
          s.layer = s.layer >= MAX_LAYER ? 0 : s.layer + 1
        }
        return
      }

      if (event.type === "session.compacted") {
        getSession(event.properties.sessionID).layer = 0
      }
    }
  }
}

function countSignals(msgs) {
  let signals = 0
  const recentEdited = new Set()

  const recent = msgs.slice(-4)
  for (const { parts } of recent) {
    if (!parts) continue
    for (const p of parts) {
      if (p.type !== "tool" || p.state?.status !== "completed") continue
      if (p.tool === "write" || p.tool === "edit") {
        recentEdited.add(p.state.input?.filePath)
      }
    }
  }

  const segment = msgs.slice(0, Math.max(0, msgs.length - 4))
  for (const { parts } of segment) {
    if (!parts) continue
    for (const p of parts) {
      if (p.type !== "tool" || p.state?.status !== "completed") continue

      if (p.tool === "read" && p.state.input?.filePath && !recentEdited.has(p.state.input.filePath)) {
        signals++
      }

      if (p.state.status === "error") {
        signals++
      }
    }
  }

  return signals
}
