﻿export const OpenClawLauncher = async () => {
  return {
    "session.created": async () => {
      const { execSync } = await import("child_process");

      let running = false;
      try {
        execSync('powershell', [
          '-NoProfile', '-Command',
          'if (Get-CimInstance Win32_Process -Filter "Name = \'node.exe\'" | Where-Object { $_.CommandLine -match \'openclaw\' }) { exit 0 } else { exit 1 }'
        ], { stdio: "pipe", timeout: 5000 });
        running = true;
      } catch {
        running = false;
      }

      if (!running) {
        try {
          execSync('schtasks /Run /TN "OpenClaw Gateway"', { stdio: "pipe", timeout: 15000 });
        } catch {
          execSync(`start /b "" openclaw gateway run --force`, { shell: "cmd.exe", timeout: 5000 });
        }
      }
    },
  };
};
