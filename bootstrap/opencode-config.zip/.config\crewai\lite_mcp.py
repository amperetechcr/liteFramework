import subprocess, os, json, sys, hashlib, re, fnmatch as _fnmatch, time as _time, gc as _gc
from contextlib import contextmanager

sys.path.insert(0, r"C:\xampp\htdocs\liteFramework")
# pixelamp se importa dentro de _build_handlers() para evitar cargo lento de crewai

PHP = r"C:\xampp\php\php.exe"
CONSOLA = r"C:\xampp\htdocs\liteFramework\consola"
PROJECT_ROOT = r"C:\xampp\htdocs\liteFramework"
TOKEN = "AI_CREW_DEFAULT_TOKEN_2024"
FROZEN_FILE = os.path.expanduser("~/.crewai/frozen.json")
_ORQUESTADOR_INICIALIZADO = False

_MODO_SESION = "normal"
_MODOS = {
    "normal":       {"leer": True, "escribir": True,  "ejecutar": True,  "confirmar": False, "desc": "Acceso completo"},
    "solo-lectura": {"leer": True, "escribir": False, "ejecutar": False, "confirmar": False, "desc": "Solo lectura"},
    "solo-plan":    {"leer": True, "escribir": False, "ejecutar": True,  "confirmar": False, "desc": "Solo planeacion"},
    "confirmar":    {"leer": True, "escribir": True,  "ejecutar": True,  "confirmar": True,  "desc": "Requiere aprobacion"},
}
_PERIMETRO_PERMITIR = []
_PERIMETRO_DENEGAR = []
_BITACORA_LOG = os.path.expanduser("~/.crewai/bitacora.log")
_PENDIENTES_FILE = os.path.expanduser("~/.crewai/pendientes.json")
_PENDIENTES_ID = 0

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8")

# ────────────────────────── helpers ──────────────────────────

def _run(args):
    err = _check_permiso("ejecutar")
    if err:
        return err
    cmd = [PHP] + args
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=30, encoding="utf-8", errors="replace")
        raw = (r.stdout or "").strip() or (r.stderr or "").strip() or "(empty)"
        pos = raw.find("{")
        if pos >= 0:
            raw = raw[pos:]
        return raw
    except subprocess.TimeoutExpired:
        return json.dumps({"error": "timeout"})
    except Exception as e:
        return json.dumps({"error": str(e)})


def _read_file(path):
    err = _check_perimetro(path)
    if err:
        return err
    full = os.path.join(PROJECT_ROOT, path)
    if not os.path.exists(full):
        return json.dumps({"error": f"file not found: {path}"})
    try:
        with open(full, "r", encoding="utf-8") as f:
            return f.read()
    except Exception as e:
        return json.dumps({"error": str(e)})


def _write_file(path, content):
    err = _check_permiso("escribir")
    if err:
        return err
    err = _check_perimetro(path)
    if err:
        return err
    frozen = _es_frozen(path)
    if frozen == "total":
        return json.dumps({"error": f"archivo congelado (total): {path}. Usa lite_freeze(accion='descongelar', archivo='{path}') primero."})
    full = os.path.join(PROJECT_ROOT, path)
    os.makedirs(os.path.dirname(full), exist_ok=True)
    try:
        with open(full, "w", encoding="utf-8") as f:
            f.write(content)
        return json.dumps({"ok": True, "path": path, "bytes": len(content)})
    except Exception as e:
        return json.dumps({"error": str(e)})


def _list_dir(path):
    full = os.path.join(PROJECT_ROOT, path)
    if not os.path.exists(full):
        return json.dumps({"error": f"path not found: {path}"})
    try:
        items = []
        for entry in sorted(os.listdir(full)):
            fp = os.path.join(full, entry)
            items.append({
                "name": entry,
                "type": "dir" if os.path.isdir(fp) else "file",
                "size": os.path.getsize(fp) if os.path.isfile(fp) else 0,
            })
        return json.dumps({"path": path, "items": items}, ensure_ascii=False)
    except Exception as e:
        return json.dumps({"error": str(e)})


def _read_dir_tree(path):
    full = os.path.join(PROJECT_ROOT, path)
    if not os.path.exists(full):
        return json.dumps({"error": f"path not found: {path}"})
    result = {"path": path, "files": [], "dirs": []}
    for root, dirs, files in os.walk(full):
        rel = os.path.relpath(root, PROJECT_ROOT)
        for d in dirs:
            result["dirs"].append(os.path.join(rel, d).replace("\\", "/"))
        for f in files:
            result["files"].append(os.path.join(rel, f).replace("\\", "/"))
    return json.dumps(result, ensure_ascii=False)


def _grep(pattern, path=".", include=""):
    root = os.path.join(PROJECT_ROOT, path)
    if not os.path.exists(root):
        return json.dumps({"error": f"path not found: {path}"})
    results = []
    for r, dirs, files in os.walk(root):
        for f in sorted(files):
            if include and not _fnmatch.fnmatch(f, include):
                continue
            fp = os.path.join(r, f)
            try:
                with open(fp, "r", encoding="utf-8", errors="replace") as fh:
                    for i, line in enumerate(fh, 1):
                        if re.search(pattern, line):
                            rel = os.path.relpath(fp, PROJECT_ROOT)
                            results.append(f"{rel}:{i}:{line.rstrip()}")
            except Exception:
                pass
    return "\n".join(results) if results else "(no matches)"


def _glob(pattern, path="."):
    import glob
    root = os.path.join(PROJECT_ROOT, path)
    if not os.path.exists(root):
        return json.dumps({"error": f"path not found: {path}"})
    cwd = os.getcwd()
    try:
        os.chdir(root)
        matches = sorted(glob.glob(pattern, recursive=True))
        return "\n".join(matches) if matches else "(no matches)"
    finally:
        os.chdir(cwd)


def _resolver_ruta(path):
    if os.path.isabs(path):
        full = os.path.normpath(path)
        root = os.path.normpath(PROJECT_ROOT)
        if full.startswith(root):
            return full
        for special in ("opencode.json", "plugins/", "openclaw/"):
            if special == "opencode.json" and path.endswith("opencode.json"):
                return os.path.expanduser("~/.config/opencode/opencode.json")
            if special == "plugins/" and "plugins" in path:
                idx = path.find("plugins")
                return os.path.expanduser("~/.config/opencode/") + path[idx:]
            if special == "openclaw/" and "openclaw" in path:
                idx = path.find("openclaw")
                return os.path.join(OPENCLAW_DIR, path[idx + 9:])
        return json.dumps({"error": f"path fuera del proyecto: {path}"})
    return os.path.join(PROJECT_ROOT, path)


def _edit(filePath, oldString, newString, replaceAll=False):
    err = _check_permiso("escribir")
    if err:
        return err
    res = _resolver_ruta(filePath)
    if isinstance(res, str) and res.startswith("{"):
        return res
    full = res
    err = _check_perimetro(full)
    if err:
        return err
    rel = os.path.relpath(full, PROJECT_ROOT)
    frozen = _es_frozen(rel)
    if frozen == "total":
        return json.dumps({"error": f"archivo congelado (total): {rel}. Usa lite_freeze(accion='descongelar', archivo='{rel}') primero."})
    if not os.path.exists(full):
        return json.dumps({"error": f"file not found: {filePath}"})
    try:
        with open(full, "r", encoding="utf-8") as f:
            content = f.read()
        if oldString not in content:
            return json.dumps({"error": "oldString not found"})
        count = content.count(oldString)
        if count > 1 and not replaceAll:
            return json.dumps({"error": f"Found {count} matches. Use replaceAll=true or provide more context."})
        n = -1 if replaceAll else 1
        new_content = content.replace(oldString, newString, n)
        with open(full, "w", encoding="utf-8") as f:
            f.write(new_content)
        return json.dumps({"ok": True, "reemplazos": count if replaceAll else 1})
    except Exception as e:
        return json.dumps({"error": str(e)})


_SINONIMOS = {
    "autenticacion": {"auth", "login", "sesion", "token", "password", "oauth"},
    "error": {"exception", "try", "catch", "throw", "debug", "log"},
    "seguridad": {"security", "permiso", "rol", "acl", "csrf", "xss"},
    "base": {"database", "db", "sql", "query", "mysql", "tabla"},
    "usuario": {"user", "operador", "cliente", "profile"},
    "archivo": {"file", "upload", "download", "subir", "storage"},
    "ruta": {"route", "url", "endpoint", "api"},
    "config": {"configuracion", "settings", "setup"},
    "email": {"mail", "correo", "smtp"},
    "pdf": {"documento", "report", "reporte"},
    "api": {"rest", "endpoint", "json", "ajax"},
    "test": {"prueba", "phpunit", "pytest", "unit"},
    "frontend": {"css", "html", "js", "vue", "template", "vista"},
    "backend": {"server", "api", "controller", "modelo"},
}


def _detectar_bloques(lineas):
    n = len(lineas)
    bloques = []
    i = 0
    while i < n:
        if not lineas[i].strip():
            i += 1
            continue
        inicio = i
        linea = lineas[i]
        es = linea.strip()

        if es.startswith(("class ", "abstract class ", "final class ", "interface ", "trait ", "enum ")):
            tipo = "class"
        elif es.startswith(("function ", "def ", "public function", "private function", "protected function", "static function")):
            tipo = "function"
        elif es.startswith(("if ", "switch ", "for ", "while ", "foreach ", "elseif ", "else", "try", "catch", "finally")):
            tipo = "control"
        elif es.startswith(("import ", "from ", "use ", "require", "include", "namespace ", "<?php", "<?", "declare(strict_types")):
            tipo = "header"
        elif es.startswith(("//", "#", "/*", "* ", "/**")):
            tipo = "comment"
        elif es.startswith(("abstract ", "final ", "private ", "protected ", "public ", "static ", "const ", "define(")):
            tipo = "member"
        else:
            tipo = "block"

        nivel = 0
        j = inicio
        while j < n:
            nl = lineas[j]
            if tipo in ("class", "function", "control"):
                nivel += nl.count("{") - nl.count("}")
                if nivel == 0 and j > inicio:
                    j += 1
                    break
            else:
                if j > inicio and not nl.strip():
                    break
            j += 1
        fin = min(j, n)
        bloques.append((inicio, fin, tipo, es[:80]))
        i = fin
    return bloques


_STOPWORDS = {"el", "la", "los", "las", "de", "del", "en", "un", "una", "y", "e", "o", "a",
               "que", "es", "por", "con", "para", "su", "se", "no", "lo", "como", "mas",
               "pero", "sus", "le", "ya", "este", "entre", "porque", "todo", "sin", "the",
               "and", "for", "are", "not", "was", "has", "but", "all", "any", "can", "get"}


def _generar_sinonimos(palabras):
    s = set()
    for p in palabras:
        for k, v in _SINONIMOS.items():
            if p in v or p == k:
                s.update(v)
                s.add(k)
    return s


def _puntuar_bloque(texto, header, palabras, sinos):
    t = texto.lower()
    h = header.lower()
    pts = 0
    for p in palabras:
        if p in h:
            pts += 4
        elif p in t:
            pts += 2
    for s in sinos:
        if s in h:
            pts += 2
        elif s in t:
            pts += 1
    return pts


def _filtrar(consulta, archivo=None, texto=None):
    if archivo:
        full = _resolve_path(archivo)
        if not os.path.exists(full):
            return json.dumps({"error": f"archivo no encontrado: {archivo}"})
        try:
            with open(full, "r", encoding="utf-8") as f:
                lineas = f.read().split("\n")
        except Exception as e:
            return json.dumps({"error": str(e)})
    elif texto:
        lineas = texto.split("\n")
    else:
        return json.dumps({"error": "archivo o texto requerido"})

    total = len(lineas)
    bloques = _detectar_bloques(lineas)
    palabras = {p for p in consulta.lower().split() if p not in _STOPWORDS and len(p) > 1}
    sinos = _generar_sinonimos(palabras)

    buenos = set()
    items = []
    for idx, (ini, fin, tipo, hdr) in enumerate(bloques):
        txt = "\n".join(lineas[ini:fin])
        pts = _puntuar_bloque(txt, hdr, palabras, sinos)
        if pts >= 4:
            buenos.add(idx)
            items.append({"ini": ini, "fin": fin, "tipo": tipo, "header": hdr, "pts": pts, "txt": txt})

    for idx, (ini, fin, tipo, hdr) in enumerate(bloques):
        if idx in buenos:
            continue
        if (idx - 1) in buenos or (idx + 1) in buenos:
            items.append({"ini": ini, "fin": fin, "tipo": tipo, "header": hdr, "pts": 0, "txt": "\n".join(lineas[ini:fin])})

    items.sort(key=lambda x: x["ini"])
    contenido = "\n\n".join(it["txt"] for it in items)
    lineas_filt = sum(it["fin"] - it["ini"] for it in items)

    return json.dumps({
        "consulta": consulta,
        "archivo": archivo or "(texto directo)",
        "total_lineas": total,
        "lineas_filtradas": lineas_filt,
        "porcentaje": round(lineas_filt / max(total, 1) * 100, 1),
        "bloques": len(items),
        "contenido": contenido,
    }, ensure_ascii=False)


def _run_crew_wrapper(args):
    from servidor.crewai.pixelamp_bridge import pixelamp  # lazy: solo se importa crewai cuando se ejecuta un crew
    tipo = args.get("tipo", "")
    tarea = args.get("tarea", "")
    if not tipo or not tarea:
        return json.dumps({"error": "tipo y tarea son requeridos"})
    try:
        from crew_flow import _run_crew
        return str(_run_crew(tipo, tarea, int(args.get("max_iter", 0)), args.get("agentes", "")))
    except Exception as e:
        return json.dumps({"error": str(e)})


# ─────────────────── declaración de comandos CLI ───────────────────

# Cada comando: (nombre_tool, descripcion, comando_cli, [parámetros MCP])
# Cada parámetro: (name, type, description, required, cli_flag or None if positional)
CLI = [
    ("lite_inicio", "Informacion general del sistema", "inicio", []),
    ("lite_list", "Lista de comandos disponibles en el CLI", "list", []),
    ("lite_migrar", "Ejecuta migraciones pendientes de Base de Datos", "migrar", []),
    ("lite_migrar_list", "Lista las migraciones pendientes", "migrar:list", []),
    ("lite_modulo_generar", "Genera un modulo CRUD completo (7 archivos: controlador, modelo, vistas, ruta, JS, CSS, test)",
     "modulo:generar", [
         ("nombre_clase", "string", "Nombre en CamelCase del modulo (ej: Producto)", True, None),
         ("tabla", "string", "Nombre de la tabla en BD (opcional, por defecto plural de nombre)", False, "--tabla"),
         ("campos", "string", "Campos en formato 'campo:tipo,...' (ej: nombre:string,precio:decimal)", False, "--campos"),
     ]),
    ("lite_proyecto_crear", "Genera un proyecto completo desde definicion JSON",
     "proyecto:crear", [
         ("nombre", "string", "Nombre del proyecto", False, "--nombre"),
         ("base_datos", "string", "Nombre de la base de datos", False, "--base-datos"),
         ("archivo", "string", "Ruta al archivo JSON de definicion", False, "--archivo"),
     ]),
    ("lite_pruebas", "Ejecuta los tests (PHPUnit)",
     "pruebas", [
         ("filtro", "string", "Filtro de test (ej: nombre de clase o metodo)", False, "--filtro"),
         ("cobertura", "boolean", "Generar reporte de cobertura", False, "--cobertura"),
     ]),
    ("lite_auditoria_exportar", "Exporta eventos de auditoria en JSON o CSV",
     "auditoria:exportar", [
         ("formato", "string", "Formato de exportacion: json o csv", False, "--formato"),
         ("nivel", "string", "Filtrar por nivel: INFO, ERROR, WARNING", False, "--nivel"),
         ("modulo", "string", "Filtrar por modulo (ej: Seguridad, Acceso)", False, "--modulo"),
         ("desde", "string", "Fecha inicio ISO (ej: 2024-01-01)", False, "--desde"),
         ("hasta", "string", "Fecha fin ISO", False, "--hasta"),
         ("ip", "string", "Filtrar por direccion IP", False, "--ip"),
         ("busqueda", "string", "Texto de busqueda libre", False, "--busqueda"),
         ("limite", "number", "Maximo de registros a exportar (default 10000)", False, "--limite"),
     ]),
    ("lite_auditoria_limpiar", "Limpia eventos antiguos de auditoria",
     "auditoria:limpiar", [
         ("dias", "number", "Conservar eventos de los ultimos N dias (default 90)", False, "--dias"),
     ]),
    ("lite_auditoria_resumen", "Resumen de eventos de auditoria", "auditoria:resumen", []),
    ("lite_mantenimiento_on", "Activa el modo mantenimiento (bloquea acceso a no-admins)", "mantenimiento:on", []),
    ("lite_mantenimiento_off", "Desactiva el modo mantenimiento", "mantenimiento:off", []),
    ("lite_lock_adquirir", "Adquiere un bloqueo exclusivo (mutex) para operaciones criticas",
     "lock:adquirir", [
         ("clave", "string", "Identificador unico del bloqueo", True, None),
         ("tiempo_maximo", "number", "Tiempo maximo de espera en segundos (default 30)", False, None),
     ]),
    ("lite_lock_liberar", "Libera un bloqueo previamente adquirido", "lock:liberar", [
        ("clave", "string", "Identificador del bloqueo a liberar", True, None),
    ]),
    ("lite_lock_estado", "Verifica si una clave esta bloqueada", "lock:estado", [
        ("clave", "string", "Identificador del bloqueo a verificar", True, None),
    ]),
    ("lite_lock_limpiar", "Limpia locks expirados del sistema", "lock:limpiar", []),
    ("lite_correo_test", "Envia un correo electronico de prueba", "correo:test", [
        ("destinatario", "string", "Correo electronico del destinatario", True, None),
    ]),
    ("lite_operador_list", "Lista todos los operadores/usuarios del sistema con su ID, nombre, email, rol y estado activo/suspendido.", "operador:list", []),
    ("lite_operador_crear", "Crea un nuevo operador/usuario en el sistema. Valida politica de contrasena y evita duplicados de email.",
     "operador:crear", [
         ("nombre", "string", "Nombre completo del operador", True, None),
         ("email", "string", "Correo electronico unico", True, None),
         ("clave", "string", "Contrasena (min 8 chars, 1 mayuscula, 1 numero, 1 simbolo)", True, None),
         ("rol", "number", "ID del rol (1=SuperAdmin, 2=Admin, 3=Operador, 4=Consultor)", False, "--rol"),
     ]),
    ("lite_operador_estado", "Activa o suspende un operador por su ID. 1=activar, 0=suspender.",
     "operador:estado", [
         ("id", "number", "ID del operador", True, None),
         ("activo", "number", "1=activar, 0=suspender", True, None),
     ]),
    ("lite_crud", "CRUD generico sobre cualquier tabla de la base de datos. Acciones: listar, leer, crear, actualizar, eliminar.",
     "crud", [
         ("tabla", "string", "Nombre de la tabla (ej: operador, auditoria, configuracion_sistema)", True, None),
         ("accion", "string", "Accion: listar, leer, crear, actualizar, eliminar", True, None),
         ("data", "string", "JSON con datos para crear/actualizar (ej: '{\"nombre\":\"valor\"}')", False, "--data"),
         ("id", "number", "ID del registro para leer/actualizar/eliminar", False, "--id"),
     ]),
    ("lite_sse_enviar", "Envia una notificacion SSE en tiempo real a un operador especifico o a todos (id=0). Aparece como notificacion push en el panel.",
     "sse:enviar", [
         ("operador_id", "number", "ID del operador destino, o 0 para enviar a todos", True, None),
         ("tipo", "string", "Tipo de evento (ej: notificacion, alerta, actualizacion)", True, None),
         ("datos", "string", "JSON con datos del evento o texto plano", False, None),
     ]),
    ("lite_iteraciones", "Diagnostica el uso de iteraciones de los agentes. Acciones: ultimas (ultimas N iteraciones), por_agente (iteraciones de un agente), resumen (stats), analizar (el PM analiza si iteraciones extras fueron por complejidad, stuck o timeout).",
     "iteraciones", [
         ("accion", "string", "Accion: ultimas, por_agente, resumen, analizar", True, None),
         ("limite", "number", "Numero de entradas para ultimas (default: 20)", False, None),
         ("agente", "string", "Nombre del agente para por_agente (ej: tech_lead)", False, None),
     ]),
    ("lite_freeze", "Gestiona archivos congelados para evitar modificaciones accidentales. Acciones: listar (muestra archivos con nivel), verificar (revisa hashes), congelar (agrega con nivel: total/menor/plan), descongelar, check (verifica un archivo). Niveles: total=ningun cambio, menor=solo typos/logging sin alterar estructura, plan=requiere plan aprobado.",
     "freeze", [
         ("accion", "string", "Accion: listar, verificar, congelar, descongelar, check, analizar", True, None),
         ("archivo", "string", "Ruta relativa del archivo (ej: mcp_server.py)", False, None),
         ("nivel", "string", "Nivel de congelamiento: total, menor, plan (default: total)", False, None),
         ("razon", "string", "Razon para congelar (requerido para accion=congelar)", False, None),
     ]),
    ("lite_diagnostico", "Diagnostica el sistema completo: BD, archivos, seguridad, configuracion PHP. Ejecuta todos los verificadores y devuelve diagnosticos, sugerencias y remedios automaticos.",
     "diagnostico:ejecutar", []),
    ("lite_diagnostico_remediar", "Ejecuta una reparacion automatica para un problema especifico detectado por lite_diagnostico. tipo ej: directorio_no_creable, tmp_dir_faltante, csrf_expirado, deadlock",
     "diagnostico:remediar", [
         ("tipo", "string", "Tipo de problema a reparar (ej: directorio_no_creable, tmp_dir_faltante, deadlock, csrf_expirado)", True, None),
     ]),
     ("lite_ia_orquestar", "Orquestador IA (alternativo): modos descubrir, buscar, ejecutar, auto.",
      "ia:orquestar", [
          ("modo", "string", "Modo: descubrir, buscar, ejecutar, o auto", True, None),
          ("param", "string", "Categoria (descubrir) / intento (buscar/auto) / helper (ejecutar)", False, None),
          ("helper", "string", "Nombre del helper (solo modo ejecutar)", False, "--helper"),
          ("metodo", "string", "Nombre del metodo (solo modo ejecutar)", False, "--metodo"),
          ("params", "string", "JSON con parametros (modos ejecutar y auto)", False, "--params"),
      ]),
]

# ─────────────────── generación de TOOLS y HANDLERS ───────────────────

MECHANICAL = [
    {
        "name": "ia",
        "description": "=== TOOL #1 OBLIGATORIO: SISTEMA DE ORQUESTACIÓN Y CONTROL DE IA === "
                       "DEBES usar este tool SIEMPRE primero para CUALQUIER operacion del sistema. "
                       "NO intentes llamar helpers directamente ni adivinar nombres de metodos. "
                       "Simplemente describi en lenguaje natural lo que necesitas y este tool lo resuelve automaticamente. "
                       "Ej: 'validar token csrf', 'formatear fecha 2024-01-15', 'hacer peticion GET a /api/productos', "
                       "'generar slug de Hola Mundo', 'calcular edad desde 1990-05-20'. "
                       "Auto-detecta el helper exacto, metodo y parametros. Si hay dudas, te devuelve sugerencias.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "intent": {
                    "type": "string",
                    "description": "Describe en lenguaje natural lo que necesitas hacer. Ej: 'generar slug de Hola Mundo', 'calcular edad desde 1990-05-20', 'validar token csrf'"
                },
                "params": {
                    "type": "string",
                    "description": "Opcional: JSON con valores exactos para parametros. Ej: '{\"texto\":\"Hola Mundo\"}'"
                }
            },
            "required": ["intent"],
        },
    },
    {
        "name": "lite_read_file",
        "description": "Lee un archivo del proyecto. path relativo a la raiz, ej: 'servidor/nucleo/Modelo.php'",
        "inputSchema": {
            "type": "object",
            "properties": {"path": {"type": "string"}},
            "required": ["path"],
        },
    },
    {
        "name": "lite_write_file",
        "description": "Escribe un archivo en el proyecto. path relativo a la raiz. Crea directorios si no existen.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "content": {"type": "string"},
            },
            "required": ["path", "content"],
        },
    },
    {
        "name": "lite_list_dir",
        "description": "Lista el contenido de un directorio del proyecto. path relativo, ej: 'servidor/nucleo'",
        "inputSchema": {
            "type": "object",
            "properties": {"path": {"type": "string"}},
        },
    },
    {
        "name": "lite_read_dir_tree",
        "description": "Arbol completo de directorios desde una ruta relativa",
        "inputSchema": {
            "type": "object",
            "properties": {"path": {"type": "string"}},
        },
    },
    {
        "name": "lite_run",
        "description": "Ejecuta cualquier comando CLI y devuelve JSON. command ej: 'auditoria:resumen', args ej: '--desde=2024-01-01 --formato=json'",
        "inputSchema": {
            "type": "object",
            "properties": {
                "command": {"type": "string"},
                "args": {"type": "string"},
            },
            "required": ["command"],
        },
    },
    {
        "name": "lite_ping",
        "description": "Health check del servidor MCP. Devuelve ok y PID. No requiere parametros.",
        "inputSchema": {
            "type": "object",
            "properties": {},
        },
    },

    {
        "name": "lite_filtrar",
        "description": "Filtra contenido irrelevante de un archivo o texto, devolviendo solo las secciones relevantes para una consulta. Ultra rapido (heuristica, sin IA). Divide por funciones, clases, imports y bloques. Ideal para reducir tokens en archivos grandes.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "consulta": {"type": "string"},
                "archivo": {"type": "string"},
                "texto": {"type": "string"},
            },
            "required": ["consulta"],
        },
    },
    {
        "name": "lite_grep",
        "description": "Busca contenido en archivos usando regex. Retorna archivo:linea:contenido.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "pattern": {"type": "string", "description": "Patron regex a buscar"},
                "path": {"type": "string", "description": "Directorio relativo (default: raiz del proyecto)"},
                "include": {"type": "string", "description": "Filtro de archivo (ej: *.php)"}
            },
            "required": ["pattern"],
        },
    },
    {
        "name": "lite_glob",
        "description": "Busca archivos por patron glob. Ej: **/*.php",
        "inputSchema": {
            "type": "object",
            "properties": {
                "pattern": {"type": "string", "description": "Patron glob (ej: **/*.php, src/**/*.css)"},
                "path": {"type": "string", "description": "Directorio base relativo (default: raiz del proyecto)"}
            },
            "required": ["pattern"],
        },
    },
    {
        "name": "lite_edit",
        "description": "Reemplaza texto exacto en un archivo. replaceAll=true para reemplazar todas las ocurrencias.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "filePath": {"type": "string", "description": "Ruta absoluta o relativa del archivo"},
                "oldString": {"type": "string", "description": "Texto exacto a reemplazar"},
                "newString": {"type": "string", "description": "Texto de reemplazo"},
                "replaceAll": {"type": "boolean", "description": "Reemplazar todas las ocurrencias (default: false)"}
            },
            "required": ["filePath", "oldString", "newString"],
        },
    },
    {
        "name": "lite_modo",
        "description": "Controla el modo de sesion de la IA. Modos: normal (acceso completo), solo-lectura (solo leer), solo-plan (leer + ejecutar comandos), confirmar (escribe pero requiere autorizacion).",
        "inputSchema": {
            "type": "object",
            "properties": {
                "accion": {"type": "string", "description": "ver (muestra modo actual) | definir (cambia modo)"},
                "modo": {"type": "string", "description": "Solo si accion=definir: normal, solo-lectura, solo-plan, confirmar"}
            },
            "required": ["accion"],
        },
    },
    {
        "name": "lite_perimetro",
        "description": "Define que rutas puede leer/escribir la IA. Restringe el acceso a archivos del proyecto.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "accion": {"type": "string", "description": "ver | definir | reset"},
                "permitir": {"type": "array", "items": {"type": "string"}, "description": "Solo si accion=definir: lista de rutas permitidas (ej: ['servidor/', 'src/'])"},
                "denegar": {"type": "array", "items": {"type": "string"}, "description": "Solo si accion=definir: lista de rutas denegadas (ej: ['.env', 'storage/'])"}
            },
            "required": ["accion"],
        },
    },
    {
        "name": "lite_bitacora",
        "description": "Consulta el registro de operaciones de la IA en la sesion actual. Cada tool call queda registrada.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "accion": {"type": "string", "description": "ver (ultimas N entradas) | exportar (todo el log)"},
                "limite": {"type": "number", "description": "Numero de entradas a mostrar (default: 50)"}
            },
            "required": ["accion"],
        },
    },
    {
        "name": "lite_autorizar",
        "description": "Gestiona la cola de operaciones pendientes de aprobacion (solo activa en modo 'confirmar').",
        "inputSchema": {
            "type": "object",
            "properties": {
                "accion": {"type": "string", "description": "listar | aprobar | rechazar | limpiar"},
                "id": {"type": "number", "description": "ID de la operacion (requerido para aprobar/rechazar)"}
            },
            "required": ["accion"],
        },
    },
]

CREWS = [
    {
        "name": "lite_equipo",
        "description": "Ejecuta un equipo de agentes para un tipo de tarea especifica. "
                       "Tipos disponibles: analisis, kickoff, revision_diseno, desarrollo, "
                       "seguridad, frontend, backend, completo, datos, investigacion, legal, "
                       "negocio, contenido, calidad, despliegue, limpieza, ui, "
                       "infraestructura, documentacion. "
                       "Tambien acepta 'agentes' personalizado: nombres separados por coma.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "tipo": {"type": "string", "description": "Tipo de tarea: analisis, desarrollo, seguridad, etc."},
                "tarea": {"type": "string", "description": "Instruccion detallada para el equipo"},
                "agentes": {"type": "string", "description": "Lista custom separada por coma (opcional)"},
                "max_iter": {"type": "number", "description": "Iteraciones para sub-agentes. 0=default del tipo."}
            },
            "required": ["tipo", "tarea"],
        },
    },
]


# ────────── check de permisos (modo + perimetro) ──────────


def _check_permiso(tipo):
    modo = _MODOS.get(_MODO_SESION, _MODOS["normal"])
    if not modo.get(tipo, True):
        return json.dumps({"error": f"Modo '{_MODO_SESION}': operacion '{tipo}' no permitida. {modo['desc']}"})
    return ""


def _check_perimetro(path):
    root = os.path.normpath(PROJECT_ROOT)
    full = os.path.normpath(path) if os.path.isabs(path) else os.path.normpath(os.path.join(root, path))
    if not full.startswith(root):
        if _PERIMETRO_PERMITIR:
            for p in _PERIMETRO_PERMITIR:
                if full.startswith(os.path.normpath(os.path.join(root, p))):
                    break
            else:
                return json.dumps({"error": f"path fuera del perimetro: {path}"})
    if _PERIMETRO_DENEGAR:
        for d in _PERIMETRO_DENEGAR:
            denied = os.path.normpath(os.path.join(root, d))
            if full.startswith(denied):
                return json.dumps({"error": f"path denegado por perimetro: {path}"})
    return ""


def _es_frozen(archivo):
    try:
        if os.path.exists(FROZEN_FILE):
            with open(FROZEN_FILE, "r", encoding="utf-8") as f:
                db = json.load(f)
            for e in db.get("files", []):
                if e["path"] == archivo or archivo.endswith(e["path"]):
                    return e.get("nivel", "total")
    except Exception:
        pass
    return ""


def _log_bitacora(tool, args, ok, ms):
    try:
        seguros = str(args)[:200]
        for s in ("clave", "password", "pass", "secret", "token", "contrasena"):
            if s in seguros.lower():
                seguros = "(argumentos filtrados)"
                break
        entry = json.dumps({
            "t": _time.time(),
            "tool": tool,
            "ok": ok,
            "ms": round(ms * 1000),
            "args": seguros,
        }, ensure_ascii=False) + "\n"
        os.makedirs(os.path.dirname(_BITACORA_LOG), exist_ok=True)
        with open(_BITACORA_LOG, "a", encoding="utf-8") as f:
            f.write(entry)
    except Exception:
        pass


# ────────── lite_modo ──────────


def _handle_modo(args):
    global _MODO_SESION
    accion = args.get("accion", "ver")
    if accion == "ver":
        m = _MODOS.get(_MODO_SESION, _MODOS["normal"])
        return json.dumps({
            "modo": _MODO_SESION,
            "descripcion": m["desc"],
            "leer": m["leer"],
            "escribir": m["escribir"],
            "ejecutar": m["ejecutar"],
            "confirmar": m["confirmar"],
            "disponibles": list(_MODOS.keys()),
        }, ensure_ascii=False)
    if accion == "definir":
        nuevo = args.get("modo", "")
        if nuevo not in _MODOS:
            return json.dumps({"error": f"modo no valido: {nuevo}. Disponibles: {list(_MODOS.keys())}"})
        _MODO_SESION = nuevo
        return json.dumps({"ok": True, "modo": nuevo, "descripcion": _MODOS[nuevo]["desc"]}, ensure_ascii=False)
    return json.dumps({"error": f"accion no valida: {accion}"})


# ────────── lite_perimetro ──────────


def _handle_perimetro(args):
    global _PERIMETRO_PERMITIR, _PERIMETRO_DENEGAR
    accion = args.get("accion", "ver")
    if accion == "ver":
        return json.dumps({
            "permitir": list(_PERIMETRO_PERMITIR),
            "denegar": list(_PERIMETRO_DENEGAR),
        }, ensure_ascii=False)
    if accion == "definir":
        _PERIMETRO_PERMITIR = args.get("permitir", [])
        _PERIMETRO_DENEGAR = args.get("denegar", [])
        return json.dumps({
            "ok": True,
            "permitir": list(_PERIMETRO_PERMITIR),
            "denegar": list(_PERIMETRO_DENEGAR),
        }, ensure_ascii=False)
    if accion == "reset":
        _PERIMETRO_PERMITIR = []
        _PERIMETRO_DENEGAR = []
        return json.dumps({"ok": True, "accion": "perimetro reseteado"})
    return json.dumps({"error": f"accion no valida: {accion}"})


# ────────── lite_bitacora ──────────


def _handle_bitacora(args):
    accion = args.get("accion", "ver")
    limite = int(args.get("limite", 50))
    if accion == "ver":
        if not os.path.exists(_BITACORA_LOG):
            return json.dumps({"entradas": [], "total": 0})
        with open(_BITACORA_LOG, "r", encoding="utf-8") as f:
            lines = [l.strip() for l in f if l.strip()]
        ultimas = [json.loads(l) for l in lines[-limite:]]
        return json.dumps({"total": len(lines), "entradas": ultimas}, ensure_ascii=False)
    if accion == "exportar":
        if not os.path.exists(_BITACORA_LOG):
            return json.dumps({"error": "bitacora vacia"})
        with open(_BITACORA_LOG, "r", encoding="utf-8") as f:
            return f.read()
    return json.dumps({"error": f"accion no valida: {accion}"})


# ────────── lite_autorizar ──────────


def _cargar_pendientes():
    if not os.path.exists(_PENDIENTES_FILE):
        return []
    try:
        with open(_PENDIENTES_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return []


def _guardar_pendientes(pendientes):
    os.makedirs(os.path.dirname(_PENDIENTES_FILE), exist_ok=True)
    try:
        with open(_PENDIENTES_FILE, "w", encoding="utf-8") as f:
            json.dump(pendientes, f, indent=2, ensure_ascii=False)
    except Exception:
        pass


def _encolar_pendiente(tool, args, desc):
    global _PENDIENTES_ID
    _PENDIENTES_ID += 1
    pend = _cargar_pendientes()
    pend.append({
        "id": _PENDIENTES_ID,
        "tool": tool,
        "args": str(args)[:200],
        "desc": desc,
        "ts": _time.time(),
    })
    _guardar_pendientes(pend)
    return _PENDIENTES_ID


def _handle_autorizar(args):
    accion = args.get("accion", "listar")
    if accion == "listar":
        pend = _cargar_pendientes()
        return json.dumps({"pendientes": pend, "total": len(pend)}, ensure_ascii=False)
    if accion == "aprobar":
        pid = args.get("id", 0)
        pend = _cargar_pendientes()
        for p in pend:
            if p["id"] == pid:
                pend.remove(p)
                _guardar_pendientes(pend)
                return json.dumps({"ok": True, "id": pid, "accion": "aprobado"})
        return json.dumps({"error": f"pendiente no encontrado: {pid}"})
    if accion == "rechazar":
        pid = args.get("id", 0)
        pend = _cargar_pendientes()
        for p in pend:
            if p["id"] == pid:
                pend.remove(p)
                _guardar_pendientes(pend)
                return json.dumps({"ok": True, "id": pid, "accion": "rechazado"})
        return json.dumps({"error": f"pendiente no encontrado: {pid}"})
    if accion == "limpiar":
        _guardar_pendientes([])
        return json.dumps({"ok": True, "accion": "cola limpiada"})
    return json.dumps({"error": f"accion no valida: {accion}"})


@contextmanager
def _frozen_lock(write=False):
    if not write:
        yield
        return
    lock = FROZEN_FILE + ".lock"
    for _ in range(50):
        try:
            fd = os.open(lock, os.O_CREAT | os.O_EXCL)
            os.close(fd)
            break
        except FileExistsError:
            _time.sleep(0.1)
    else:
        raise TimeoutError("frozen.json lock timeout")
    try:
        yield
    finally:
        os.remove(lock)


def _handle_freeze(args):
    accion = args.get("accion", "")
    archivo = args.get("archivo", "")
    nivel = args.get("nivel", "total")
    razon = args.get("razon", "")

    with _frozen_lock(accion in ("congelar", "descongelar")):
        if not os.path.exists(FROZEN_FILE):
            with open(FROZEN_FILE, "w", encoding="utf-8") as f:
                json.dump({"files": [], "created": ""}, f, ensure_ascii=False)

        with open(FROZEN_FILE, "r", encoding="utf-8") as f:
            db = json.load(f)

        if accion == "listar":
            total = [e for e in db["files"] if e.get("nivel") == "total"]
            menor = [e for e in db["files"] if e.get("nivel") == "menor"]
            plan = [e for e in db["files"] if e.get("nivel") == "plan"]
            frozen_names = {e["path"] for e in db["files"]}
            descongelados = []
            for fname in sorted(os.listdir(CREWAI_DIR)):
                if not fname.endswith((".py", ".json", ".md")):
                    continue
                if fname.startswith("__") or fname == "frozen.json":
                    continue
                if fname not in frozen_names:
                    descongelados.append(fname)
            return json.dumps({
                "congelados": len(db["files"]),
                "descongelados": len(descongelados),
                "no_congelados": descongelados,
                "total": [{"path": e["path"], "razon": e["razon"]} for e in total],
                "menor": [{"path": e["path"], "razon": e["razon"]} for e in menor],
                "plan": [{"path": e["path"], "razon": e["razon"]} for e in plan],
                "sugerencia": "Usa lite_freeze(accion='check', archivo='X') antes de tocar archivos no congelados." if descongelados else "Todo congelado.",
            }, ensure_ascii=False)

        if accion == "verificar":
            resultados = []
            for e in db["files"]:
                path = _resolve_path(e["path"])
                try:
                    with open(path, "rb") as fp:
                        h = hashlib.sha256(fp.read()).hexdigest()[:16]
                    match = h == e["hash"]
                except FileNotFoundError:
                    match = False
                    h = ""
                resultados.append({"path": e["path"], "esperado": e["hash"], "actual": h, "match": match})
            return json.dumps({"resultados": resultados}, ensure_ascii=False)

        if accion == "congelar":
            if not archivo:
                return json.dumps({"error": "archivo requerido"})
            if not razon:
                return json.dumps({"error": "razon requerida"})
            path = _resolve_path(archivo)
            if not os.path.exists(path):
                return json.dumps({"error": f"archivo no encontrado: {path}"})
            with open(path, "rb") as fp:
                h = hashlib.sha256(fp.read()).hexdigest()[:16]
            if nivel not in ("total", "menor", "plan"):
                nivel = "total"
            for e in db["files"]:
                if e["path"] == archivo:
                    e["hash"] = h
                    e["nivel"] = nivel
                    e["razon"] = razon
                    break
            else:
                db["files"].append({"path": archivo, "hash": h, "nivel": nivel, "razon": razon})
            with open(FROZEN_FILE, "w", encoding="utf-8") as f:
                json.dump(db, f, indent=2, ensure_ascii=False)
            return json.dumps({"ok": True, "archivo": archivo, "hash": h, "nivel": nivel}, ensure_ascii=False)

        if accion == "descongelar":
            if not archivo:
                return json.dumps({"error": "archivo requerido"})
            db["files"] = [e for e in db["files"] if e["path"] != archivo]
            with open(FROZEN_FILE, "w", encoding="utf-8") as f:
                json.dump(db, f, indent=2, ensure_ascii=False)
            return json.dumps({"ok": True, "archivo": archivo, "accion": "descongelado"}, ensure_ascii=False)

        if accion == "check":
            if not archivo:
                return json.dumps({"error": "archivo requerido"})
            for e in db["files"]:
                if e["path"] == archivo:
                    path = _resolve_path(archivo)
                    try:
                        with open(path, "rb") as fp:
                            h = hashlib.sha256(fp.read()).hexdigest()[:16]
                        match = h == e["hash"]
                    except FileNotFoundError:
                        h, match = "", False
                    return json.dumps({
                        "path": archivo, "congelado": True, "nivel": e["nivel"],
                        "match": match, "hash_actual": h, "hash_esperado": e["hash"],
                        "razon": e["razon"],
                    }, ensure_ascii=False)
            return json.dumps({
                "path": archivo, "congelado": False,
                "mensaje": "NO esta congelado. Investigar por que antes de modificar.",
            }, ensure_ascii=False)

        if accion == "analizar":
            crewai_dir = os.path.dirname(os.path.abspath(__file__))
            opencode_file = os.path.expanduser("~/.config/opencode/opencode.json")
            resultados = []

            for fname in sorted(os.listdir(crewai_dir)):
                if not fname.endswith((".py", ".json", ".md")):
                    continue
                if fname.startswith("__"):
                    continue
                if fname == "frozen.json":
                    continue
                fpath = os.path.join(crewai_dir, fname)
                congelado = None
                for e in db["files"]:
                    if e["path"] == fname:
                        congelado = e
                        break
                if congelado:
                    continue
                try:
                    with open(fpath, "rb") as fp:
                        h = hashlib.sha256(fp.read()).hexdigest()[:16]
                except Exception:
                    h = ""
                refs = []
                codigo_muerto = []
                if fname.endswith(".py"):
                    for otro in sorted(os.listdir(crewai_dir)):
                        if not otro.endswith(".py"):
                            continue
                        if otro == fname:
                            continue
                        try:
                            with open(os.path.join(crewai_dir, otro)) as fp:
                                c = fp.read()
                            if fname.replace(".py", "") in c:
                                refs.append(otro)
                        except Exception:
                            pass
                resultados.append({
                    "path": fname,
                    "hash": h,
                    "en_uso": len(refs) > 0 or fname in ("REGLAS.md",),
                    "referencias": refs[:5],
                    "sugerencia": "analizar antes de modificar" if not refs else "verificar si debe congelarse",
                })

            return json.dumps({
                "no_congelados": resultados,
                "resumen": f"{len(resultados)} archivos sin congelar en ~/.config/crewai/",
                "sugerencia": "Usar lite_freeze(accion='check', archivo='X') antes de tocar cualquier archivo.",
            }, ensure_ascii=False)

        return json.dumps({"error": f"accion no valida: {accion}"})


_ITER_LOG = os.path.expanduser("~/.crewai/iteraciones.log")


def _handle_iteraciones(args):
    accion = args.get("accion", "ultimas")
    limite = int(args.get("limite", 20))
    agente = args.get("agente", "")

    if not os.path.exists(_ITER_LOG):
        return json.dumps({"error": "No hay iteraciones registradas aun. Ejecuta un kickoff primero."})

    with open(_ITER_LOG, "r", encoding="utf-8") as f:
        lines = [line.strip() for line in f if line.strip()]

    if accion == "ultimas":
        ultimas = [json.loads(l) for l in lines[-limite:]]
        return json.dumps({"accion": "ultimas", "total": len(lines), "mostrando": len(ultimas), "iteraciones": ultimas}, ensure_ascii=False)

    if accion == "por_agente":
        if not agente:
            return json.dumps({"error": "agente requerido"})
        filtradas = [json.loads(l) for l in lines if agente in l]
        return json.dumps({"accion": "por_agente", "agente": agente, "total": len(filtradas), "iteraciones": filtradas[-limite:]}, ensure_ascii=False)

    if accion == "resumen":
        agentes = {}
        for l in lines:
            try:
                d = json.loads(l)
                a = d.get("agent", "?")
                agentes.setdefault(a, {"count": 0, "total_len": 0, "total_ms": 0, "acciones": {}})
                agentes[a]["count"] += 1
                agentes[a]["total_len"] += d.get("len", 0)
                agentes[a]["total_ms"] += d.get("ms", 0)
                act = d.get("action", "?")
                agentes[a]["acciones"][act] = agentes[a]["acciones"].get(act, 0) + 1
            except Exception:
                pass
        stats = []
        for a, data in sorted(agentes.items()):
            stats.append({
                "agente": a,
                "iteraciones": data["count"],
                "promedio_output": data["total_len"] // max(data["count"], 1),
                "promedio_ms": data["total_ms"] // max(data["count"], 1),
                "acciones": data["acciones"],
            })
        return json.dumps({"accion": "resumen", "total_iteraciones": len(lines), "agentes": stats}, ensure_ascii=False)

    if accion == "analizar":
        if len(lines) < 2:
            return json.dumps({"accion": "analizar", "diagnostico": "Pocas iteraciones para analizar. Ejecuta mas tareas primero."})
        ultimos = [json.loads(l) for l in lines[-20:]]
        agentes_afectados = set(d.get("agent", "?") for d in ultimos)
        outputs = [d.get("len", 0) for d in ultimos]
        tiempos = [d.get("ms", 0) for d in ultimos]
        outputs_cero = sum(1 for o in outputs if o < 100)
        tiempos_altos = sum(1 for t in tiempos if t > 30000)
        mismo_agente = len(agentes_afectados) <= 2
        acciones_repetidas = len(set(d.get("action", "") for d in ultimos)) <= 3

        if outputs_cero > len(ultimos) * 0.5:
            diag = "POSIBLE STUCK: mas del 50% de las ultimas iteraciones tienen output casi vacio. El agente podria estar en un bucle sin progreso."
        elif tiempos_altos > len(ultimos) * 0.3:
            diag = "RESPUESTA LENTA: mas del 30% de las iteraciones tomaron >30s cada una. La IA podria estar tardando en responder."
        elif mismo_agente and acciones_repetidas and len(ultimos) > 10:
            diag = "TAREA COMPLEJA: el mismo agente consume multiples iteraciones con acciones variadas. Requiere mas tiempo."
        else:
            diag = "NORMAL: patron de iteraciones esperado. No se detectan anomalias."

        return json.dumps({
            "accion": "analizar",
            "diagnostico": diag,
            "agentes": list(agentes_afectados),
            "ultimas_iteraciones": len(ultimos),
        }, ensure_ascii=False)

    return json.dumps({"error": f"accion no valida: {accion}"})


FW_ROOT = r"C:\xampp\htdocs\liteFramework"
CREWAI_DIR = os.path.dirname(os.path.abspath(__file__))
OPENCLAW_DIR = os.path.expanduser("~/.openclaw")


def _resolve_path(archivo):
    if archivo == "opencode.json":
        return os.path.expanduser("~/.config/opencode/opencode.json")
    if archivo.startswith("plugins/"):
        return os.path.expanduser("~/.config/opencode/") + archivo
    if archivo.startswith("openclaw/"):
        return os.path.join(OPENCLAW_DIR, archivo[9:])
    if archivo.startswith(("servidor/", "src/", "tests/", "rutas/", "plantillas/")):
        return os.path.join(FW_ROOT, archivo)
    raiz_test = os.path.join(FW_ROOT, archivo)
    if os.path.exists(raiz_test):
        return raiz_test
    return os.path.join(CREWAI_DIR, archivo)


def _build_tools():
    tools = list(MECHANICAL)

    # CLI tools
    for name, desc, cmd, params in CLI:
        props = {}
        required = []
        for pname, ptype, pdesc, preq, _ in params:
            schema_type = "number" if ptype == "number" else "string" if ptype == "boolean" else ptype
            props[pname] = {"type": schema_type, "description": pdesc}
            if ptype == "boolean":
                props[pname] = {"type": "boolean", "description": pdesc}
            if preq:
                required.append(pname)
        tools.append({
            "name": name,
            "description": desc,
            "inputSchema": {"type": "object", "properties": props, "required": required},
        })

    tools.extend(CREWS)
    return tools


def _build_handlers():
    handlers = {
        "lite_read_file": lambda a: _read_file(a["path"]),
        "lite_write_file": lambda a: _write_file(a["path"], a["content"]),
        "lite_list_dir": lambda a: _list_dir(a.get("path", ".")),
        "lite_read_dir_tree": lambda a: _read_dir_tree(a.get("path", "servidor")),
        "lite_ping": lambda a: json.dumps({"ok": True, "pid": os.getpid()}),

        "ia": lambda a: _run([CONSOLA, "ia:orquestar", "auto", a["intent"], f"--params={a.get('params', '{}')}", "--json", f"--token={TOKEN}"]),
        "lite_run": lambda a: _run([CONSOLA, a["command"]] + (a.get("args", "").split() if a.get("args") else []) + ["--json", f"--token={TOKEN}"]),
        "lite_filtrar": lambda a: _filtrar(a["consulta"], a.get("archivo"), a.get("texto")),
        "lite_grep": lambda a: _grep(a["pattern"], a.get("path", "."), a.get("include", "")),
        "lite_glob": lambda a: _glob(a["pattern"], a.get("path", ".")),
        "lite_edit": lambda a: _edit(a["filePath"], a["oldString"], a["newString"], a.get("replaceAll", False)),
    }

    for name, desc, cmd, params in CLI:
        def _make_handler(cmd_name, param_defs):
            return lambda a: _run(
                [CONSOLA, cmd_name] +
                _build_cli_args(a, param_defs) +
                ["--json", f"--token={TOKEN}"]
            )
        handlers[name] = _make_handler(cmd, params)

    # Excluir lite_freeze e lite_iteraciones del autogenerado (no son comandos CLI)
    for skip in ("lite_freeze", "lite_iteraciones"):
        if skip in handlers:
            del handlers[skip]

    handlers.update({
        "lite_equipo": lambda a: _run_crew_wrapper(a),
        "lite_freeze": lambda a: _handle_freeze(a),
        "lite_iteraciones": lambda a: _handle_iteraciones(a),
        "lite_modo": lambda a: _handle_modo(a),
        "lite_perimetro": lambda a: _handle_perimetro(a),
        "lite_bitacora": lambda a: _handle_bitacora(a),
        "lite_autorizar": lambda a: _handle_autorizar(a),
    })
    return handlers


def _build_cli_args(args, param_defs):
    result = []
    for pname, ptype, pdesc, preq, cli_flag in param_defs:
        val = args.get(pname)
        if val is None:
            continue
        if cli_flag is None:
            # positional argument
            result.append(str(val))
        else:
            if ptype == "boolean":
                if val:
                    result.append(cli_flag)
            else:
                result.append(f"{cli_flag}={val}")
    return result


TOOLS = _build_tools()
HANDLERS = _build_handlers()

# ─────────────────── MCP protocol (JSON-RPC over stdio) ───────────────────


def send_response(msg):
    sys.stdout.write(json.dumps(msg, ensure_ascii=False) + "\n")
    sys.stdout.flush()


def recv():
    line = sys.stdin.readline()
    if not line:
        return None
    return json.loads(line)


def handle(req):
    method = req.get("method", "")
    _id = req.get("id")
    if method == "initialize":
        return send_response({
            "jsonrpc": "2.0", "id": _id,
            "result": {
                "protocolVersion": "2024-11-05",
                "capabilities": {"tools": {}},
                "serverInfo": {"name": "lite_mcp", "version": "2.0.0"},
            },
        })
    if method == "notifications/initialized":
        return
    if method == "tools/list":
        return send_response({"jsonrpc": "2.0", "id": _id, "result": {"tools": TOOLS}})
    if method == "tools/call":
        name = req["params"]["name"]
        args = req["params"].get("arguments", {})

        global _ORQUESTADOR_INICIALIZADO
        if name == "ia":
            _ORQUESTADOR_INICIALIZADO = True
        elif name.startswith("lite_") and name != "lite_ping" and not _ORQUESTADOR_INICIALIZADO:
            return send_response({
                "jsonrpc": "2.0", "id": _id,
                "error": {
                    "code": -32000,
                    "message": (
                        "BLOQUEO: Debes llamar 'ia' PRIMERO antes de usar tools del sistema.\n\n"
                        "El orquestador debe inicializarse para darte contexto sobre helpers, "
                        "reglas activas y estado del sistema.\n\n"
                        "Accion:\n"
                        "  1. ia(intent='inicializar') o describe tu tarea en lenguaje natural\n"
                        "  2. El orquestador devuelve contexto completo\n"
                        "  3. Una vez ejecutado, todas las tools quedan disponibles\n\n"
                        "Tools bloqueadas: lite_read_file, lite_write_file, lite_list_dir, "
                        "lite_read_dir_tree, lite_run, lite_filtrar, lite_grep, lite_glob, "
                        "lite_edit, lite_freeze, lite_equipo, "
                        "lite_iteraciones y todas las lite_* CLI."
                    ),
                },
            })

        handler = HANDLERS.get(name)
        if not handler:
            return send_response({
                "jsonrpc": "2.0", "id": _id,
                "error": {"code": -32601, "message": f"Unknown tool: {name}"},
            })

        modo = _MODOS.get(_MODO_SESION, _MODOS["normal"])
        t0 = _time.time()
        try:
            if modo["confirmar"] and name in ("lite_write_file", "lite_edit", "lite_run"):
                desc = f"{name}({str(args)[:100]})"
                pid = _encolar_pendiente(name, args, desc)
                result = json.dumps({
                    "ok": False, "pendiente": True, "id": pid,
                    "mensaje": f"Operacion encolada para aprobacion (id={pid}). Usa lite_autorizar(accion='aprobar', id={pid}) para ejecutarla.",
                })
            else:
                result = handler(args)

            ms = _time.time() - t0
            _log_bitacora(name, args, True, ms)

            r = send_response({
                "jsonrpc": "2.0", "id": _id,
                "result": {"content": [{"type": "text", "text": str(result)}]},
            })
            _gc.collect()
            return r
        except Exception as e:
            ms = _time.time() - t0
            _log_bitacora(name, args, False, ms)
            return send_response({
                "jsonrpc": "2.0", "id": _id,
                "error": {"code": -32603, "message": str(e)},
            })
    return send_response({
        "jsonrpc": "2.0", "id": _id,
        "error": {"code": -32601, "message": f"Unknown method: {method}"},
    })


if __name__ == "__main__":
    while True:
        req = recv()
        if req is None:
            break
        handle(req)
