﻿export const CrewAIPreloader = async () => {
  return {
    "session.created": async () => {
      const { execSync } = await import("child_process");
      execSync(
        `start /b "" C:\\Users\\Tech\\.crewai-venv\\Scripts\\python.exe -c "import crewai; print('crewai preloaded')" > NUL 2>&1`,
        { shell: "cmd.exe", timeout: 15000 }
      );
    },
  };
};
